<?php
/**
 * Turnkey Multi-Demo Registration & Dependency Handler for BizPro Agency Companion.
 *
 * @package BizPro_Agency_Companion
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register all 7 individual niche demo imports.
 *
 * @return array
 */
function bizpro_companion_ocdi_import_files() {
	$plugin_demo_dir = trailingslashit( BIZPRO_COMPANION_PATH ) . 'demo-data/';
	$plugin_img_dir  = trailingslashit( BIZPRO_COMPANION_PATH ) . 'assets/images/demos/';
	$theme_img_dir   = trailingslashit( get_template_directory() ) . 'assets/images/demos/';

	if ( file_exists( $plugin_img_dir . 'demo-main.png' ) ) {
		$img_base = trailingslashit( BIZPRO_COMPANION_URL ) . 'assets/images/demos/';
	} elseif ( file_exists( $theme_img_dir . 'demo-main.png' ) ) {
		$img_base = trailingslashit( get_template_directory_uri() ) . 'assets/images/demos/';
	} else {
		$img_base = trailingslashit( BIZPRO_COMPANION_URL ) . 'assets/images/';
	}

	return array(
		array(
			'import_file_name'           => esc_html__( 'Main Agency (Multi-Purpose)', 'bizpro-agency-companion' ),
			'categories'                 => array( 'Agency', 'Multi-Purpose' ),
			'local_import_file'          => $plugin_demo_dir . 'content.xml',
			'import_preview_image_url'   => $img_base . 'demo-main.png',
			'import_notice'              => esc_html__( 'Sets up the complete multi-purpose flagship demo with Services, Portfolio Case Studies, Team, Pricing Tables, and Contact.', 'bizpro-agency-companion' ),
		),
		array(
			'import_file_name'           => esc_html__( 'Visa & Immigration Consultancy', 'bizpro-agency-companion' ),
			'categories'                 => array( 'Visa & Immigration', 'Consultancy' ),
			'local_import_file'          => $plugin_demo_dir . 'content.xml',
			'import_preview_image_url'   => $img_base . 'demo-visa.png',
			'import_notice'              => esc_html__( 'Sets up the dedicated Visa & Immigration agency demo as your homepage with 2-Minute Eligibility Checker, Country Pathways directory, and 4-Step Process.', 'bizpro-agency-companion' ),
		),
		array(
			'import_file_name'           => esc_html__( 'Travel & Tour Agency', 'bizpro-agency-companion' ),
			'categories'                 => array( 'Travel & Tours' ),
			'local_import_file'          => $plugin_demo_dir . 'content.xml',
			'import_preview_image_url'   => $img_base . 'demo-travel.png',
			'import_notice'              => esc_html__( 'Sets up the dedicated Travel & Tour Operator demo as your homepage with Floating Search Bar, Destination Cards, Tour Packages, and Reviews.', 'bizpro-agency-companion' ),
		),
		array(
			'import_file_name'           => esc_html__( 'IT Solutions & Cloud Services', 'bizpro-agency-companion' ),
			'categories'                 => array( 'IT Solutions', 'Technology' ),
			'local_import_file'          => $plugin_demo_dir . 'content.xml',
			'import_preview_image_url'   => $img_base . 'demo-it.png',
			'import_notice'              => esc_html__( 'Sets up the modern IT & Software agency demo as your homepage with Tech Stack Matrix, Production Case Studies, SLA Guarantee, and Retainers.', 'bizpro-agency-companion' ),
		),
		array(
			'import_file_name'           => esc_html__( 'Business & Management Consulting', 'bizpro-agency-companion' ),
			'categories'                 => array( 'Business Consulting', 'Corporate' ),
			'local_import_file'          => $plugin_demo_dir . 'content.xml',
			'import_preview_image_url'   => $img_base . 'demo-consulting.png',
			'import_notice'              => esc_html__( 'Sets up the executive Business Management consulting demo as your homepage with Strategic Advisory Practices, 4-Phase Methodology, and Mandate Retainers.', 'bizpro-agency-companion' ),
		),
		array(
			'import_file_name'           => esc_html__( 'Corporate Enterprise', 'bizpro-agency-companion' ),
			'categories'                 => array( 'Corporate', 'Enterprise' ),
			'local_import_file'          => $plugin_demo_dir . 'content.xml',
			'import_preview_image_url'   => $img_base . 'demo-corporate.png',
			'import_notice'              => esc_html__( 'Sets up the institutional Corporate agency demo with Enterprise Capabilities, Global Footprint, and Boardroom Governance.', 'bizpro-agency-companion' ),
		),
		array(
			'import_file_name'           => esc_html__( 'Digital Products & SaaS Store', 'bizpro-agency-companion' ),
			'categories'                 => array( 'eCommerce', 'Digital Products', 'SaaS' ),
			'local_import_file'          => file_exists( $plugin_demo_dir . 'content-ecommerce.xml' ) ? $plugin_demo_dir . 'content-ecommerce.xml' : $plugin_demo_dir . 'content.xml',
			'import_preview_image_url'   => $img_base . 'demo-digital.png',
			'import_notice'              => class_exists( 'WooCommerce' )
				? esc_html__( '✅ [WooCommerce Active] Ready to import digital products, cart, checkout flows, and Bento grid.', 'bizpro-agency-companion' )
				: esc_html__( '⚠️ [REQUIRED PLUGIN] This demo requires WooCommerce to sell digital downloads and handle checkout. Please install and activate WooCommerce before importing.', 'bizpro-agency-companion' ),
		),
	);
}
// If theme has not already registered them, register companion demos
if ( ! function_exists( 'bizpro_agency_ocdi_import_files' ) ) {
	add_filter( 'pt-ocdi/import_files', 'bizpro_companion_ocdi_import_files' );
	add_filter( 'ocdi/import_files',    'bizpro_companion_ocdi_import_files' );
}

/**
 * Enforce WooCommerce check before starting import.
 */
function bizpro_companion_ocdi_before_content_import( $selected_import ) {
	$demo_name  = isset( $selected_import['import_file_name'] ) ? $selected_import['import_file_name'] : '';
	$categories = isset( $selected_import['categories'] ) ? (array) $selected_import['categories'] : array();

	$is_ecommerce = in_array( 'eCommerce', $categories, true )
		|| false !== stripos( $demo_name, 'eCommerce' )
		|| false !== stripos( $demo_name, 'Digital Products' )
		|| false !== stripos( $demo_name, 'SaaS Store' );

	if ( $is_ecommerce && ! class_exists( 'WooCommerce' ) ) {
		$install_url = admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' );
		$back_url    = admin_url( 'themes.php?page=one-click-demo-import' );

		wp_die(
			sprintf(
				'<div style="max-width:560px;margin:50px auto;padding:36px;background:#ffffff;border-radius:18px;box-shadow:0 20px 40px rgba(0,0,0,0.08);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;text-align:center;">' .
				'<div style="font-size:54px;line-height:1;margin-bottom:16px;">🛒</div>' .
				'<h2 style="color:#ef4444;font-size:24px;font-weight:800;margin:0 0 12px;">%s</h2>' .
				'<p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 24px;">%s</p>' .
				'<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">' .
				'<a href="%s" class="button button-primary button-hero" style="font-weight:700;padding:12px 26px;height:auto;line-height:1.4;border-radius:8px;">%s</a>' .
				'<a href="%s" class="button button-hero" style="padding:12px 24px;height:auto;line-height:1.4;border-radius:8px;">%s</a>' .
				'</div>' .
				'</div>',
				esc_html__( 'WooCommerce Plugin Required!', 'bizpro-agency-companion' ),
				sprintf(
					esc_html__( 'The "%s" demo strictly requires the WooCommerce plugin to generate digital products, configure cart & checkout flows, and manage orders. Please install and activate WooCommerce before importing this demo.', 'bizpro-agency-companion' ),
					esc_html( $demo_name )
				),
				esc_url( $install_url ),
				esc_html__( '⚡ Install WooCommerce Now', 'bizpro-agency-companion' ),
				esc_url( $back_url ),
				esc_html__( '← Back to Demos', 'bizpro-agency-companion' )
			),
			esc_html__( 'Required Plugin Missing', 'bizpro-agency-companion' ),
			array( 'response' => 200, 'back_link' => true )
		);
	}
}
add_action( 'pt-ocdi/before_content_import', 'bizpro_companion_ocdi_before_content_import', 5 );
add_action( 'ocdi/before_content_import',    'bizpro_companion_ocdi_before_content_import', 5 );