<?php
/**
 * Plugin Name:       BizPro Agency Companion
 * Plugin URI:        https://example.com/bizpro-agency
 * Description:       Official companion plugin for BizPro Agency theme. Adds the Visa Pathways custom post type and ready-made Elementor templates (FAQ, Pricing, Visa Search). Demo content is imported with One Click Demo Import from the theme.
 * Version:           1.2.0
 * Author:            BizPro Themes
 * Author URI:        https://example.com
 * Text Domain:       bizpro-agency-companion
 * Domain Path:       /languages
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.8
 * Requires PHP:      7.4
 *
 * @package BizPro_Agency_Companion
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BIZPRO_COMPANION_VERSION', '1.2.0' );
define( 'BIZPRO_COMPANION_PATH', plugin_dir_path( __FILE__ ) );
define( 'BIZPRO_COMPANION_URL', plugin_dir_url( __FILE__ ) );

/**
 * Check if BizPro Agency theme is currently active.
 *
 * @return bool
 */
function bizpro_companion_is_theme_active() {
	$theme    = wp_get_theme();
	$template = $theme->get_template();
	return ( 0 === strpos( $template, 'bizpro-agency' ) );
}

/**
 * Load plugin textdomain for translations.
 */
function bizpro_companion_load_textdomain() {
	load_plugin_textdomain( 'bizpro-agency-companion', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'bizpro_companion_load_textdomain' );

/**
 * Load CPT and OCDI Integrations.
 */
function bizpro_companion_init() {
	// 1. Visa Pathways CPT
	if ( file_exists( BIZPRO_COMPANION_PATH . 'inc/cpt-visa.php' ) ) {
		require_once BIZPRO_COMPANION_PATH . 'inc/cpt-visa.php';
	}
}
add_action( 'after_setup_theme', 'bizpro_companion_init', 25 );

if ( ! bizpro_companion_is_theme_active() ) {
	/**
	 * Admin notice if theme is not active.
	 */
	function bizpro_companion_theme_inactive_notice() {
		echo '<div class="notice notice-warning is-dismissible">';
		echo '<p>' . esc_html__( 'BizPro Agency Companion requires the BizPro Agency theme to be active.', 'bizpro-agency-companion' ) . '</p>';
		echo '</div>';
	}
	add_action( 'admin_notices', 'bizpro_companion_theme_inactive_notice' );
}
